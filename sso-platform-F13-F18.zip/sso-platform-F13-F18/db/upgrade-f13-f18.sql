USE sso;

CREATE TABLE IF NOT EXISTS app_profile (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, client_id VARCHAR(100) NOT NULL UNIQUE,
 app_code VARCHAR(100) NOT NULL UNIQUE, display_name VARCHAR(60) NOT NULL,
 client_secret_hash VARCHAR(255) NOT NULL, redirect_uris TEXT NOT NULL,
 enabled TINYINT NOT NULL DEFAULT 1, created_at DATETIME(6) NOT NULL,
 updated_at DATETIME(6) NOT NULL, version BIGINT NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS role_application (
 role_id BIGINT NOT NULL, application_id BIGINT NOT NULL, PRIMARY KEY(role_id,application_id));
CREATE TABLE IF NOT EXISTS security_event (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, event_key VARCHAR(100) NOT NULL UNIQUE,
 actor_user_id BIGINT, event_type VARCHAR(48) NOT NULL, status VARCHAR(16) NOT NULL DEFAULT 'OPEN',
 occurred_at DATETIME(6) NOT NULL, handler_id BIGINT, handled_at DATETIME(6),
 note VARCHAR(500), version BIGINT NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS login_failure_window (
 user_id BIGINT PRIMARY KEY, started_at DATETIME(6) NOT NULL,
 threshold_snapshot INT NOT NULL, window_minutes INT NOT NULL, lock_minutes INT NOT NULL);
CREATE TABLE IF NOT EXISTS extension_schema_version (version INT PRIMARY KEY);
