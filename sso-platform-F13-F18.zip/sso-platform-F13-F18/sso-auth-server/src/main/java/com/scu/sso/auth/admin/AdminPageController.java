package com.scu.sso.auth.admin;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class AdminPageController {
 private final AdminService service;
 public AdminPageController(AdminService service){this.service=service;}
 @GetMapping("/admin") public String index(HttpServletRequest request){try {service.admin(request);} catch(com.scu.sso.auth.web.ApiException ex) {throw new org.springframework.web.server.ResponseStatusException(ex.getStatus(),ex.getMessage());}return "admin";}
}
