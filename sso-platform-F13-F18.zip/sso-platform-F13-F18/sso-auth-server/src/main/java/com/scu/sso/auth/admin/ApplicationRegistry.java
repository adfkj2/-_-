package com.scu.sso.auth.admin;
import java.util.*;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.server.authorization.client.*;
import com.scu.sso.auth.config.RegisteredClientFactory;
@Repository
public class ApplicationRegistry implements RegisteredClientRepository {
 private final JdbcTemplate db;
 public ApplicationRegistry(JdbcTemplate db, ExtensionSchema schema, PasswordEncoder encoder,
 @Value("${sso.clients.app-a.secret}") String a, @Value("${sso.clients.app-b.secret}") String b) {
  this.db=db;
  seed("app-a","教务信息服务 A",a,"http://127.0.0.1:8081/login/oauth2/code/sso",encoder);
  seed("app-b","图书信息服务 B",b,"http://127.0.0.1:8082/login/oauth2/code/sso",encoder);
 }
 private void seed(String id,String name,String secret,String uri,PasswordEncoder encoder){
  db.update("INSERT IGNORE INTO app_profile(client_id,app_code,display_name,client_secret_hash,redirect_uris,enabled,created_at,updated_at) VALUES(?,?,?,?,?,1,UTC_TIMESTAMP(6),UTC_TIMESTAMP(6))",id,id,name,encoder.encode(secret),uri);
 }
 public void save(RegisteredClient client){ throw new UnsupportedOperationException("请通过应用管理维护"); }
 public RegisteredClient findById(String id){ return find("client_id",id); }
 public RegisteredClient findByClientId(String id){ return find("client_id",id); }
 private RegisteredClient find(String column,String value){
  var rows=db.queryForList("SELECT * FROM app_profile WHERE "+column+"=?",value);
  if(rows.isEmpty())return null;
  var r=rows.get(0);
  var base=RegisteredClientFactory.build((String)r.get("client_id"),(String)r.get("display_name"),
    ((String)r.get("redirect_uris")).split("\n")[0],"unused",new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder());
  return RegisteredClient.from(base).id((String)r.get("client_id")).clientSecret((String)r.get("client_secret_hash"))
   .redirectUris(uris->{uris.clear();uris.addAll(Arrays.asList(((String)r.get("redirect_uris")).split("\n")));}).build();
 }
}
