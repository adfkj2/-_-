package com.scu.sso.auth.admin;
import org.springframework.stereotype.Component;
import org.springframework.context.event.EventListener;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
@Component
public class ExtensionSeeder {
 private final JdbcTemplate db;
 public ExtensionSeeder(JdbcTemplate db,ExtensionSchema schema){this.db=db;}
 @EventListener(ApplicationReadyEvent.class)
 @Transactional
 public void seed(){
  if(db.queryForObject("SELECT count(*) FROM extension_schema_version WHERE version=1",Long.class)>0)return;
  db.update("INSERT IGNORE INTO sys_role(code,name,enabled,system_role) VALUES('A_ONLY','仅教务演示',1,0)");
  db.update("DELETE ur FROM user_role ur JOIN sys_user u ON u.id=ur.user_id JOIN sys_role r ON r.id=ur.role_id WHERE u.username='aonly01' AND r.code='USER'");
  db.update("INSERT IGNORE INTO user_role(user_id,role_id) SELECT u.id,r.id FROM sys_user u JOIN sys_role r ON r.code='A_ONLY' WHERE u.username='aonly01'");
  db.update("INSERT IGNORE INTO role_application(role_id,application_id) SELECT r.id,a.id FROM sys_role r JOIN app_profile a ON a.client_id IN ('app-a','app-b') WHERE r.code='USER'");
  db.update("INSERT IGNORE INTO role_application(role_id,application_id) SELECT r.id,a.id FROM sys_role r JOIN app_profile a ON a.client_id='app-a' WHERE r.code='A_ONLY'");
  db.update("INSERT INTO extension_schema_version VALUES(1)");
 }
}
