package com.scu.sso.auth.admin;
import jakarta.servlet.http.HttpServletRequest;
import java.util.*;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/admin")
public class AdminController {
 private final AdminService service;
 public AdminController(AdminService service){this.service=service;}
 @GetMapping("/apps") public Object apps(HttpServletRequest r){service.admin(r);return service.apps();}
 @PostMapping("/apps") public Object create(@RequestBody Map<String,Object>b,HttpServletRequest r){return service.saveApp(null,b,service.admin(r),r);}
 @PutMapping("/apps/{id}") public Object update(@PathVariable long id,@RequestBody Map<String,Object>b,HttpServletRequest r){return service.saveApp(id,b,service.admin(r),r);}
 @PutMapping("/apps/{id}/status") public Object status(@PathVariable long id,@RequestBody Map<String,Object>b,HttpServletRequest r){service.appStatus(id,b,service.admin(r),r);return Map.of("message","状态已更新");}
 @GetMapping("/roles") public Object roles(HttpServletRequest r){service.admin(r);return service.roles();}
 @GetMapping("/roles/{id}/apps") public Object grants(@PathVariable long id,HttpServletRequest r){service.admin(r);return service.grants(id);}
 @PutMapping("/roles/{id}/apps") public Object grants(@PathVariable long id,@RequestBody List<Long> ids,HttpServletRequest r){service.grants(id,ids,service.admin(r),r);return Map.of("message","授权已保存，下一次受保护访问立即生效");}
 @GetMapping("/audits") public Object audits(@RequestParam Map<String,String>q,HttpServletRequest r){return service.audits(q,service.admin(r),r);}
 @GetMapping("/stats") public Object stats(@RequestParam String start,@RequestParam String end,@RequestParam(defaultValue="day") String group,@RequestParam(required=false) String metric,HttpServletRequest r){service.admin(r);if(metric!=null&&!java.util.Set.of("loginSuccess","loginFailure","ssoSuccess","applicationSuccess").contains(metric))throw service.error(400,"ERR-AUD-03","不支持的指标名");return service.stats(start,end,group);}
 @GetMapping("/policy") public Object policy(HttpServletRequest r){service.admin(r);return service.policy();}
 @PutMapping("/policy") public Object policy(@RequestBody Map<String,Object>b,HttpServletRequest r){service.policy(b,service.admin(r),r);return Map.of("message","新策略已保存；已有会话沿用原快照");}
 @GetMapping("/events") public Object events(@RequestParam(defaultValue="") String status,@RequestParam String start,@RequestParam String end,HttpServletRequest r){service.admin(r);return service.events(status,start,end);}
 @PutMapping("/events/{id}") public Object event(@PathVariable long id,@RequestBody Map<String,Object>b,HttpServletRequest r){service.event(id,b,service.admin(r),r);return Map.of("message","事件已更新，账号锁定不受影响");}
}
