package com.scu.sso.auth.admin;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;
@Service
public class LoginFailureService {
 private final JdbcTemplate db;
 public LoginFailureService(JdbcTemplate db,ExtensionSchema schema){this.db=db;}
 @Transactional
 public Long failure(String username){
  if(username==null)return null;
  var users=db.queryForList("SELECT * FROM sys_user WHERE username=? FOR UPDATE",username.toLowerCase(Locale.ROOT));
  if(users.isEmpty())return null;
  var u=users.get(0);long id=((Number)u.get("id")).longValue();
  Instant now=Instant.now();
  if(u.get("locked_until")!=null&&AdminService.instant(u.get("locked_until")).isAfter(now))return id;
  var windows=db.queryForList("SELECT * FROM login_failure_window WHERE user_id=?",id);
  Map<String,Object> w=windows.isEmpty()?null:windows.get(0);
  if(w==null||!AdminService.instant(w.get("started_at")).plusSeconds(((Number)w.get("window_minutes")).longValue()*60).isAfter(now)){
   var policy=db.queryForMap("SELECT * FROM security_policy WHERE id=1");
   db.update("DELETE FROM login_failure_window WHERE user_id=?",id);
   db.update("INSERT INTO login_failure_window VALUES(?,?,?,?,?)",id,Timestamp.from(now),policy.get("failure_threshold"),policy.get("failure_window_minutes"),policy.get("lock_minutes"));
   w=db.queryForMap("SELECT * FROM login_failure_window WHERE user_id=?",id);u.put("failed_count",0);
  }
  int count=((Number)u.get("failed_count")).intValue()+1;
  db.update("UPDATE sys_user SET failed_count=? WHERE id=?",count,id);
  if(count>=((Number)w.get("threshold_snapshot")).intValue()){
   Instant until=now.plusSeconds(((Number)w.get("lock_minutes")).longValue()*60);
   db.update("UPDATE sys_user SET locked_until=? WHERE id=?",Timestamp.from(until),id);
   db.update("INSERT IGNORE INTO security_event(event_key,actor_user_id,event_type,occurred_at) VALUES(?,?,'ACCOUNT_LOCKED',?)","LOCK:"+id+":"+until,id,Timestamp.from(now));
  }
  return id;
 }
 @Transactional
 public void success(long id){db.update("UPDATE sys_user SET failed_count=0,locked_until=NULL WHERE id=?",id);db.update("DELETE FROM login_failure_window WHERE user_id=?",id);}
}
