package com.scu.sso.auth.admin;

import com.scu.sso.auth.audit.AuditWriter;
import com.scu.sso.auth.web.ApiException;
import jakarta.servlet.http.HttpServletRequest;
import java.net.URI;
import java.sql.Timestamp;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AdminService {
 private final JdbcTemplate db;
 private final PasswordEncoder encoder;
 private final AuditWriter audit;
 public AdminService(JdbcTemplate db, PasswordEncoder encoder, AuditWriter audit, ExtensionSchema schema){this.db=db;this.encoder=encoder;this.audit=audit;}
 public long admin(HttpServletRequest req){
  if(req.getUserPrincipal()==null)throw error(403,"ERR-ACCESS-01","需要管理员身份");
  var ids=db.queryForList("SELECT DISTINCT u.id FROM sys_user u JOIN user_role ur ON ur.user_id=u.id JOIN sys_role r ON r.id=ur.role_id WHERE u.username=? AND u.status='ACTIVE' AND r.code='ADMIN' AND r.enabled=1",Long.class,req.getUserPrincipal().getName());
  if(ids.isEmpty())throw error(403,"ERR-ACCESS-01","仅管理员可以操作");
  return ids.get(0);
 }
 public ApiException error(int status,String code,String message){return new ApiException(HttpStatus.valueOf(status),code,message);}
 private void log(String type,long user,HttpServletRequest req,String note){audit.record(type,"SUCCESS",user,req,note);}
 public List<Map<String,Object>> apps(){return db.queryForList("SELECT id,client_id,display_name AS name,redirect_uris,CASE WHEN enabled=1 THEN 'ENABLED' ELSE 'DISABLED' END AS status,version,'********' AS secret FROM app_profile ORDER BY id");}
 public List<Map<String,Object>> roles(){return db.queryForList("SELECT id,code,name,enabled FROM sys_role ORDER BY id");}
 private Map<String,Object> app(long id){var list=db.queryForList("SELECT * FROM app_profile WHERE id=?",id);if(list.isEmpty())throw error(404,"ERR-APP-03","应用不存在");return list.get(0);}
 @Transactional
 public Map<String,Object> saveApp(Long id,Map<String,Object> b,long actor,HttpServletRequest req){
  String client=text(b,"clientId"),name=text(b,"name"),uris=Arrays.stream(text(b,"redirectUris").split("\n")).map(String::trim).distinct().collect(java.util.stream.Collectors.joining("\n")),status=text(b,"status");
  if(name.isBlank()||name.length()>60||client.isBlank()||client.length()>100||!Set.of("ENABLED","DISABLED").contains(status))throw error(422,"ERR-APP-02","名称、客户端标识或状态不合法");
  if(uris.isBlank())throw error(422,"ERR-APP-02","至少填写一个回调地址");
  for(String value:uris.split("\n")){
   try{URI uri=URI.create(value.trim());if(value.length()>512||!"https".equals(uri.getScheme())||uri.getHost()==null||uri.getRawFragment()!=null||uri.getRawUserInfo()!=null||value.contains("*"))throw new IllegalArgumentException();}
   catch(Exception ex){throw error(422,"ERR-APP-02","新回调地址必须为 HTTPS，不允许通配符、片段或用户信息");}
  }
  Long count=db.queryForObject("SELECT count(*) FROM app_profile WHERE client_id=? AND id<>?",Long.class,client,id==null?-1:id);
  if(count>0)throw error(409,"ERR-APP-01","客户端标识已存在");
  Map<String,Object> result=new LinkedHashMap<>();
  if(id==null){
   String secret=UUID.randomUUID().toString()+UUID.randomUUID().toString();
   db.update("INSERT INTO app_profile(client_id,app_code,display_name,client_secret_hash,redirect_uris,enabled,created_at,updated_at) VALUES(?,?,?,?,?,?,UTC_TIMESTAMP(6),UTC_TIMESTAMP(6))",client,java.util.UUID.nameUUIDFromBytes(client.getBytes(java.nio.charset.StandardCharsets.UTF_8)).toString().replace("-",""),name,encoder.encode(secret),uris,status.equals("ENABLED"));
   result.put("secret",secret);result.put("message","创建成功，密钥只显示这一次，请立即保存");
  }else{
   var old=app(id);if(!old.get("client_id").equals(client))throw error(422,"ERR-APP-02","客户端标识创建后不能修改");
   int changed=db.update("UPDATE app_profile SET display_name=?,redirect_uris=?,enabled=?,updated_at=UTC_TIMESTAMP(6),version=version+1 WHERE id=? AND version=?",name,uris,status.equals("ENABLED"),id,number(b,"version"));
   if(changed==0)throw error(409,"ERR-APP-04","应用已被修改，请刷新");
   revokeApp(client);result.put("message","保存成功，旧授权已撤销");
  }
  log(id==null?"APP_CREATE":"APP_UPDATE",actor,req,"client="+client+";status="+status);
  return result;
 }
 @Transactional
 public void appStatus(long id,Map<String,Object>b,long actor,HttpServletRequest req){
  String status=text(b,"status");if(!Set.of("ENABLED","DISABLED").contains(status))throw error(422,"ERR-APP-02","应用状态不合法");
  String client=(String)app(id).get("client_id");
  if(db.update("UPDATE app_profile SET enabled=?,updated_at=UTC_TIMESTAMP(6),version=version+1 WHERE id=? AND version=?",status.equals("ENABLED"),id,number(b,"version"))==0)throw error(409,"ERR-APP-04","应用已被修改，请刷新");
  if(status.equals("DISABLED"))revokeApp(client);
  log("APP_STATUS",actor,req,"client="+client+";status="+status);
 }
 private void revokeApp(String client){
  db.update("DELETE l FROM authorization_session_link l JOIN oauth2_authorization a ON a.id=l.authorization_id WHERE a.registered_client_id=?",client);
  db.update("DELETE FROM oauth2_authorization WHERE registered_client_id=?",client);
 }
 public List<Long> grants(long role){return db.queryForList("SELECT application_id FROM role_application WHERE role_id=?",Long.class,role);}
 @Transactional
 public void grants(long role,List<Long> ids,long actor,HttpServletRequest req){
  if(db.queryForObject("SELECT count(*) FROM sys_role WHERE id=? AND enabled=1",Long.class,role)==0)throw error(422,"ERR-APP-02","角色不存在或未启用");
  if(ids==null)throw error(422,"ERR-APP-02","应用列表不能为空引用");
  for(long id:ids)if(db.queryForObject("SELECT count(*) FROM app_profile WHERE id=? AND enabled=1",Long.class,id)==0)throw error(422,"ERR-APP-02","应用不存在或未启用");
  db.update("DELETE FROM role_application WHERE role_id=?",role);
  for(long id:new LinkedHashSet<>(ids))db.update("INSERT INTO role_application(role_id,application_id) VALUES(?,?)",role,id);
  log("APPLICATION_GRANT",actor,req,"role="+role+";apps="+ids);
 }
 public boolean allowed(String username,String client){
  return db.queryForObject("SELECT count(*) FROM sys_user u JOIN user_role ur ON ur.user_id=u.id JOIN sys_role r ON r.id=ur.role_id AND r.enabled=1 JOIN role_application ra ON ra.role_id=r.id JOIN app_profile a ON a.id=ra.application_id WHERE u.username=? AND u.status='ACTIVE' AND a.client_id=? AND a.enabled=1",Long.class,username,client)>0;
 }
 public boolean enabled(String client){return db.queryForObject("SELECT count(*) FROM app_profile WHERE client_id=? AND enabled=1",Long.class,client)>0;}
 public record Range(Instant start,Instant end){}
 public Range range(String start,String end){
  try{Instant a=Instant.parse(start),b=Instant.parse(end);if(!a.isBefore(b)||Duration.between(a,b).compareTo(Duration.ofDays(90))>0)throw new IllegalArgumentException();return new Range(a,b);}
  catch(Exception ex){throw error(422,"ERR-AUD-01","时间区间必须为有效 ISO 时间，起点早于终点且跨度不超过90天");}
 }
 public Map<String,Object> audits(Map<String,String> q,long actor,HttpServletRequest req){
  Range r=range(q.get("start"),q.get("end"));int page=parse(q.getOrDefault("page","1")),size=parse(q.getOrDefault("size","20"));
  if(page<1||size<1||size>100)throw error(422,"ERR-AUD-02","页码从1开始，页大小为1至100");
  StringBuilder where=new StringBuilder(" WHERE e.occurred_at>=? AND e.occurred_at<?");
  List<Object> args=new ArrayList<>(List.of(Timestamp.from(r.start()),Timestamp.from(r.end())));
  for(var field:Map.of("type","e.event_type","user","u.username","application","a.client_id","result","e.result","requestId","e.request_id").entrySet()){
   String value=q.get(field.getKey());if(value!=null&&!value.isBlank()){where.append(" AND ").append(field.getValue()).append("=?");args.add(value);}
  }
  String from=" FROM audit_event e LEFT JOIN sys_user u ON u.id=e.actor_user_id LEFT JOIN app_profile a ON a.id=e.application_id";
  long total=db.queryForObject("SELECT count(*)"+from+where,Long.class,args.toArray());
  args.add(size);args.add((long)(page-1)*size);
  var items=db.queryForList("SELECT e.id,u.username,a.client_id,e.event_type,e.result,e.occurred_at,e.request_id,e.source_masked,e.detail_json"+from+where+" ORDER BY e.occurred_at DESC,e.id DESC LIMIT ? OFFSET ?",args.toArray());
  log("AUDIT_QUERY",actor,req,"count="+total);
  return Map.of("items",items,"total",total,"page",page,"size",size);
 }
 private int parse(String s){try{return Integer.parseInt(s);}catch(Exception ex){throw error(422,"ERR-AUD-02","分页参数必须为整数");}}
 public List<Map<String,Object>> stats(String start,String end,String group){
  Range r=range(start,end);if(!Set.of("day","application").contains(group))throw error(400,"ERR-AUD-03","分组仅支持 day 或 application");
  LinkedHashMap<String,Map<String,Object>> result=new LinkedHashMap<>();
  if(group.equals("day")){
   LocalDate last=r.end().minusNanos(1).atZone(ZoneId.of("Asia/Shanghai")).toLocalDate();
   for(LocalDate day=r.start().atZone(ZoneId.of("Asia/Shanghai")).toLocalDate();!day.isAfter(last);day=day.plusDays(1))result.put(day.toString(),bucket(day.toString()));
  }else{for(var a:apps()){String key=(String)a.get("client_id");result.put(key,bucket(key));}result.put("认证中心",bucket("认证中心"));}
  var rows=db.queryForList("SELECT e.event_type,e.occurred_at,a.client_id FROM audit_event e LEFT JOIN app_profile a ON a.id=e.application_id WHERE e.occurred_at>=? AND e.occurred_at<? AND e.result='SUCCESS' AND e.event_type IN ('LOGIN_SUCCESS','SSO_AUTHENTICATE','SSO_AUTHORIZE') OR (e.occurred_at>=? AND e.occurred_at<? AND e.event_type='LOGIN_FAIL')",Timestamp.from(r.start()),Timestamp.from(r.end()),Timestamp.from(r.start()),Timestamp.from(r.end()));
  Map<String,String> names=Map.of("LOGIN_SUCCESS","loginSuccess","LOGIN_FAIL","loginFailure","SSO_AUTHENTICATE","ssoSuccess","SSO_AUTHORIZE","applicationSuccess");
  for(var row:rows){String key=group.equals("day")?instant(row.get("occurred_at")).atZone(ZoneId.of("Asia/Shanghai")).toLocalDate().toString():Objects.toString(row.get("client_id"),"认证中心");var bucket=result.computeIfAbsent(key,this::bucket);String metric=names.get(row.get("event_type"));bucket.put(metric,((Number)bucket.get(metric)).longValue()+1);}
  return new ArrayList<>(result.values());
 }
 private Map<String,Object> bucket(String key){Map<String,Object> r=new LinkedHashMap<>();r.put("group",key);for(String s:List.of("loginSuccess","loginFailure","ssoSuccess","applicationSuccess"))r.put(s,0L);return r;}
 public Map<String,Object> policy(){return db.queryForMap("SELECT * FROM security_policy WHERE id=1");}
 @Transactional
 public void policy(Map<String,Object>b,long actor,HttpServletRequest req){
  int idle=bounded(b,"idleTimeoutMinutes",5,120),absolute=bounded(b,"absoluteTimeoutHours",1,24),window=bounded(b,"failureWindowMinutes",5,60),threshold=bounded(b,"failureThreshold",3,10),lock=bounded(b,"lockMinutes",5,60);
  if(idle>absolute*60)throw error(422,"ERR-POL-01","空闲时限不得大于绝对时限");
  if(db.update("UPDATE security_policy SET idle_timeout_minutes=?,absolute_timeout_hours=?,failure_window_minutes=?,failure_threshold=?,lock_minutes=?,updated_by=?,updated_at=UTC_TIMESTAMP(6),version=version+1 WHERE id=1 AND version=?",idle,absolute,window,threshold,lock,actor,number(b,"version"))==0)throw error(409,"ERR-POL-02","策略已被其他人修改，请刷新后再提交");
  log("POLICY_UPDATE",actor,req,"version="+number(b,"version"));
 }
 private int bounded(Map<String,Object>b,String k,int min,int max){long n=number(b,k);if(n<min||n>max)throw error(422,"ERR-POL-01",k+" 超出允许范围");return (int)n;}
 public List<Map<String,Object>> events(String status,String start,String end){
  Range r=range(start,end);if(!status.isBlank()&&!Set.of("OPEN","ACKNOWLEDGED","CLOSED").contains(status))throw error(422,"ERR-EVT-02","事件状态不合法");
  return db.queryForList("SELECT e.*,u.username,h.username AS handler FROM security_event e JOIN sys_user u ON u.id=e.actor_user_id LEFT JOIN sys_user h ON h.id=e.handler_id WHERE e.occurred_at>=? AND e.occurred_at<? AND (?='' OR e.status=?) ORDER BY e.id DESC LIMIT 100",Timestamp.from(r.start()),Timestamp.from(r.end()),status,status);
 }
 @Transactional
 public void event(long id,Map<String,Object>b,long actor,HttpServletRequest req){
  String action=text(b,"action"),note=text(b,"note");
  String before,after;
  if(action.equals("ack")){before="OPEN";after="ACKNOWLEDGED";}
  else if(action.equals("close")){before="ACKNOWLEDGED";after="CLOSED";if(note.isBlank()||note.length()>500)throw error(422,"ERR-EVT-01","关闭时需填写1至500字符的处理说明");}
  else throw error(409,"ERR-EVT-02","不允许的处理动作");
  if(db.update("UPDATE security_event SET status=?,handler_id=?,handled_at=UTC_TIMESTAMP(6),note=?,version=version+1 WHERE id=? AND status=? AND version=?",after,actor,note,id,before,number(b,"version"))==0)throw error(409,"ERR-EVT-02","状态或版本冲突，请刷新；必须先确认再关闭");
  log("SECURITY_EVENT_"+after,actor,req,"event="+id);
 }
 public static String text(Map<String,Object>b,String key){return Objects.toString(b.get(key),"").trim();}
 public long number(Map<String,Object>b,String key){try{return Long.parseLong(Objects.toString(b.get(key)));}catch(Exception ex){throw error(422,"ERR-VALIDATION","字段 "+key+" 必须为整数");}}
 public static Instant instant(Object value){return value instanceof Timestamp t?t.toInstant():((LocalDateTime)value).toInstant(ZoneOffset.UTC);}
}
