package com.scu.sso.auth.admin;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scu.sso.auth.repository.AuthSessionRepository;
import com.scu.sso.auth.session.SessionService;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.filter.OncePerRequestFilter;

/** 在协议安全链内实时检查应用状态、角色授权和中心会话，不缓存正向结果。 */
public class LiveAccessFilter extends OncePerRequestFilter {
 private final AdminService admin;
 private final JdbcTemplate db;
 private final AuthSessionRepository sessions;
 private final SessionService service;
 public LiveAccessFilter(AdminService admin,JdbcTemplate db,AuthSessionRepository sessions,SessionService service){this.admin=admin;this.db=db;this.sessions=sessions;this.service=service;}
 protected void doFilterInternal(HttpServletRequest req,HttpServletResponse res,FilterChain chain)throws ServletException,IOException{
  String uri=req.getRequestURI(),client=req.getParameter("client_id");
  if(uri.equals("/oauth2/authorize")&&client!=null){
   if(!admin.enabled(client)){reject(res,403,"ERR-AUTH-06","应用未登记或已停用");return;}
   var auth=SecurityContextHolder.getContext().getAuthentication();
   if(auth!=null&&auth.isAuthenticated()&&!auth.getName().equals("anonymousUser")&&!admin.allowed(auth.getName(),client)){
    reject(res,403,"ERR-AUTH-05","未获得该应用访问权限");return;
   }
  }
  if(uri.equals("/oauth2/introspect")||uri.equals("/oauth2/token")){
   String field=uri.endsWith("introspect")?"access_token_value":"authorization_code_value";
   String value=req.getParameter(uri.endsWith("introspect")?"token":"code");
   if(value!=null){
    var rows=db.queryForList("SELECT a.principal_name,a.registered_client_id,l.sid FROM oauth2_authorization a LEFT JOIN authorization_session_link l ON l.authorization_id=a.id WHERE a."+field+"=?",value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    if(!rows.isEmpty()){
     var row=rows.get(0);String username=(String)row.get("principal_name"),app=(String)row.get("registered_client_id");
     var session=sessions.findById(Objects.toString(row.get("sid"),""));
     boolean active=session.isPresent()&&service.isActive(session.get());
     if(!active){
      if(session.isPresent())service.expire(session.get());
      res.setStatus(uri.endsWith("introspect")?200:400);res.setContentType("application/json;charset=UTF-8");res.getWriter().write(uri.endsWith("introspect")?"{\"active\":false}":"{\"error\":\"invalid_grant\"}");return;
     }
     if(!admin.allowed(username,app)){
      if(uri.endsWith("introspect"))reject(res,403,"ERR-AUTH-05","未获得该应用访问权限");else reject(res,403,"ERR-AUTH-05","应用已停用或访问授权已撤销");return;
     }
     service.touch(session.get());
    }
   }
  }
  chain.doFilter(req,res);
 }
 private void reject(HttpServletResponse r,int status,String code,String msg)throws IOException{
  r.setStatus(status);r.setContentType("application/json;charset=UTF-8");new ObjectMapper().writeValue(r.getWriter(),Map.of("code",code,"message",msg,"active",false));
 }
}
